"""الملف 4: الملف الرئيسي - شغّله وهو يعمل كل حاجة"""
import matplotlib.pyplot as plt

from simulator import simulate_season
from standings import build_table, points_by_round, season_stats, title_chances
from charts import (plot_final_table, plot_points_race,
                    plot_goals_hist, plot_title_chances)


def main():
    matches = simulate_season(seed=7)
    table = build_table(matches)

    print("=== League Table ===")
    print(table)
    print(f"\nChampion: {table.index[0]}")

    print("\n=== Season Stats ===")
    for k, v in season_stats(matches).items():
        print(f"{k}: {v:,.1f}")

    chances = title_chances(500)
    print("\n=== Title Chances (%) ===")
    print(chances.round(1))

    matches.to_csv("matches.csv", index=False)
    plot_final_table(table)
    plot_points_race(points_by_round(matches))
    plot_goals_hist(matches)
    plot_title_chances(chances)
    print("\nتم حفظ الرسومات في فولدر output")
    plt.show()


if __name__ == "__main__":
    main()
