"""الملف 1: محاكاة المباريات باستخدام numpy"""
import numpy as np
import pandas as pd

# (قوة الهجوم, ضعف الدفاع) - كل ما الهجوم أعلى والدفاع أقل يبقى الفريق أقوى
TEAMS = {
    "Cairo FC":      (1.8, 0.8),
    "Alex United":   (1.6, 0.9),
    "Delta SC":      (1.4, 1.0),
    "Nile Stars":    (1.3, 1.0),
    "Giza Lions":    (1.2, 1.1),
    "Aswan Eagles":  (1.1, 1.1),
    "Suez Sharks":   (1.0, 1.2),
    "Luxor Pharaohs": (0.9, 1.3),
}

HOME_ADVANTAGE = 1.15


def make_rounds(teams):
    """جدول الدوري (كل فريق يلعب مع الباقي ذهاب وإياب)"""
    teams = list(teams)
    n = len(teams)
    first_leg = []
    for _ in range(n - 1):
        first_leg.append([(teams[i], teams[n - 1 - i]) for i in range(n // 2)])
        teams = [teams[0]] + [teams[-1]] + teams[1:-1]
    second_leg = [[(a, h) for h, a in rnd] for rnd in first_leg]
    return first_leg + second_leg


def simulate_season(seed=None):
    rng = np.random.default_rng(seed)
    rows = []
    for round_no, fixtures in enumerate(make_rounds(TEAMS), start=1):
        for home, away in fixtures:
            lam_home = TEAMS[home][0] * TEAMS[away][1] * HOME_ADVANTAGE
            lam_away = TEAMS[away][0] * TEAMS[home][1]
            rows.append({
                "round": round_no,
                "home": home,
                "away": away,
                "home_goals": rng.poisson(lam_home),
                "away_goals": rng.poisson(lam_away),
            })
    return pd.DataFrame(rows)


if __name__ == "__main__":
    print(simulate_season(seed=7).head(10))
