"""الملف 2: حساب الترتيب والإحصائيات باستخدام pandas"""
import numpy as np
import pandas as pd


def _long_format(matches):
    """نحوّل كل مباراة لصفين: واحد لكل فريق"""
    home = matches.rename(columns={"home": "team", "home_goals": "gf", "away_goals": "ga"})
    away = matches.rename(columns={"away": "team", "away_goals": "gf", "home_goals": "ga"})
    cols = ["round", "team", "gf", "ga"]
    df = pd.concat([home[cols], away[cols]], ignore_index=True)
    df["points"] = np.where(df["gf"] > df["ga"], 3, np.where(df["gf"] == df["ga"], 1, 0))
    return df


def build_table(matches):
    df = _long_format(matches)
    table = df.groupby("team").agg(
        played=("points", "size"),
        wins=("points", lambda s: (s == 3).sum()),
        draws=("points", lambda s: (s == 1).sum()),
        losses=("points", lambda s: (s == 0).sum()),
        gf=("gf", "sum"),
        ga=("ga", "sum"),
        points=("points", "sum"),
    )
    table["gd"] = table["gf"] - table["ga"]
    table = table.sort_values(["points", "gd", "gf"], ascending=False)
    table.insert(0, "rank", np.arange(1, len(table) + 1))
    return table


def points_by_round(matches):
    """مجموع نقاط كل فريق بعد كل جولة"""
    df = _long_format(matches)
    pivot = df.pivot_table(index="round", columns="team", values="points", aggfunc="sum")
    return pivot.cumsum()


def season_stats(matches):
    goals = matches["home_goals"] + matches["away_goals"]
    return {
        "Matches": len(matches),
        "Total goals": int(goals.sum()),
        "Goals per match": float(np.mean(goals)),
        "Home wins %": float((matches["home_goals"] > matches["away_goals"]).mean() * 100),
        "Draws %": float((matches["home_goals"] == matches["away_goals"]).mean() * 100),
        "Away wins %": float((matches["home_goals"] < matches["away_goals"]).mean() * 100),
        "Biggest win": int((matches["home_goals"] - matches["away_goals"]).abs().max()),
    }


def title_chances(n_seasons=500):
    """نحاكي مواسم كتير ونشوف مين بياخد الدوري أكتر"""
    from simulator import simulate_season
    champions = [build_table(simulate_season()).index[0] for _ in range(n_seasons)]
    return pd.Series(champions).value_counts() / n_seasons * 100
