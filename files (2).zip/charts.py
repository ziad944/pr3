"""الملف 3: الرسومات باستخدام matplotlib"""
import os
import matplotlib.pyplot as plt

OUTPUT_DIR = "output"


def _save(fig, name):
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    fig.savefig(os.path.join(OUTPUT_DIR, name), dpi=150, bbox_inches="tight")


def plot_final_table(table):
    fig, ax = plt.subplots(figsize=(8, 5))
    data = table["points"].sort_values()
    colors = ["#e8744c" if t == table.index[0] else "#4c9be8" for t in data.index]
    ax.barh(data.index, data.values, color=colors)
    ax.set_title("Final Points")
    ax.set_xlabel("Points")
    _save(fig, "final_points.png")
    return fig


def plot_points_race(race):
    fig, ax = plt.subplots(figsize=(9, 5))
    for team in race.columns:
        ax.plot(race.index, race[team], marker="o", markersize=3, label=team)
    ax.set_title("Points Race")
    ax.set_xlabel("Round")
    ax.set_ylabel("Points")
    ax.grid(alpha=0.3)
    ax.legend(fontsize=8, ncol=2)
    _save(fig, "points_race.png")
    return fig


def plot_goals_hist(matches):
    fig, ax = plt.subplots(figsize=(7, 5))
    goals = matches["home_goals"] + matches["away_goals"]
    ax.hist(goals, bins=range(0, goals.max() + 2), color="#6bbf59",
            edgecolor="white", align="left")
    ax.set_title("Goals per Match")
    ax.set_xlabel("Goals")
    ax.set_ylabel("Matches")
    _save(fig, "goals_hist.png")
    return fig


def plot_title_chances(chances):
    fig, ax = plt.subplots(figsize=(8, 5))
    chances.sort_values().plot(kind="barh", ax=ax, color="#9b6bd8")
    ax.set_title("Title Chances (500 simulated seasons)")
    ax.set_xlabel("Chance of winning the league (%)")
    _save(fig, "title_chances.png")
    return fig
